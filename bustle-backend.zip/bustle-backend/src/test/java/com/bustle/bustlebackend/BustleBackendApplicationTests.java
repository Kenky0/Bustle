package com.bustle.bustlebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BustleBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
